package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class MakananController {

    @FXML
    private Button btnBarang;

    @FXML
    private Button btnHapusMkn;

    @FXML
    private Button btnKategoriMkn;

    @FXML
    private Button btnPenjualanMkn;

    @FXML
    private Button btnTambahMkn;

    @FXML
    private Button btnUbahMkn;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtHome;

    @FXML
    void barangMenu(ActionEvent event) {

    }

    @FXML
    void hapusMknMenu(ActionEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void kategoriMknMenu(ActionEvent event) {

    }

    @FXML
    void penjualanMknMenu(ActionEvent event) {

    }

    @FXML
    void tambahMknMenu(ActionEvent event) {

    }

    @FXML
    void ubahMknMenu(ActionEvent event) {

    }

}
