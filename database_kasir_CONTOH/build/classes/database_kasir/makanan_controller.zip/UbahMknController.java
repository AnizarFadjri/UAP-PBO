package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class UbahMknController {

    @FXML
    private Button btnBarang;

    @FXML
    private Button btnMakanan;

    @FXML
    private Button btnUbahMkn;

    @FXML
    private TextField fieldBulan;

    @FXML
    private TextField fieldDiskonMkn;

    @FXML
    private TextField fieldHargaMkn;

    @FXML
    private TextField fieldIDSebelum;

    @FXML
    private TextField fieldIDSesudah;

    @FXML
    private TextField fieldJumlahMkn;

    @FXML
    private TextField fieldKategoriMkn;

    @FXML
    private TextField fieldNamaMkn;

    @FXML
    private TextField fieldTahun;

    @FXML
    private TextField fieldTanggal;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtHome;

    @FXML
    private Text txtMakanan;

    @FXML
    private Text txtUbah;

    @FXML
    void barangMenu(MouseEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void makananMenu(ActionEvent event) {

    }

}
