package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class UbahPjlMknController {

    @FXML
    private Button btnBarang;

    @FXML
    private Button btnMakanan;

    @FXML
    private Button btnUbahPjlMkn;

    @FXML
    private TextField fieldIDPjlMknSebelum;

    @FXML
    private TextField fieldIDPjlMknSesudah;

    @FXML
    private TextField fieldJmlMkn;

    @FXML
    private TextField fieldNamaMkn;

    @FXML
    private TextField fieldPajakMkn;

    @FXML
    private TextField fieldStokMkn;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtHome;

    @FXML
    private Text txtMakanan;

    @FXML
    private Text txtPenjualanMkn;

    @FXML
    void barangMenu(ActionEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void makananMenu(MouseEvent event) {

    }

    @FXML
    void penjualanMknMenu(ActionEvent event) {

    }

}
