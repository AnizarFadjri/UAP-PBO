package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class TambahMknController {

    @FXML
    private Button btnBarang;

    @FXML
    private Button btnMakanan;

    @FXML
    private Button btnTambahMkn;

    @FXML
    private TextField fieldBulan;

    @FXML
    private TextField fieldDiskonMkn;

    @FXML
    private TextField fieldHargaMkn;

    @FXML
    private TextField fieldID;

    @FXML
    private TextField fieldJumlahMkn;

    @FXML
    private TextField fieldKategoriMkn;

    @FXML
    private TextField fieldNamaMkn;

    @FXML
    private TextField fieldTahun;

    @FXML
    private TextField fieldTanggal;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtHome;

    @FXML
    private Text txtMakanan;

    @FXML
    void barangMenu(ActionEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void makananMenu(ActionEvent event) {

    }

}
