package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class HapusKtgMknController {

    @FXML
    private Button btnBarang;

    @FXML
    private Button btnHapusKtgMkn;

    @FXML
    private Button btnMakanan;

    @FXML
    private TextField fieldIDKtgMkn;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtHome;

    @FXML
    private Text txtKategori;

    @FXML
    private Text txtMakanan;

    @FXML
    void barangMenu(ActionEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void kategoriMenu(MouseEvent event) {

    }

    @FXML
    void kategoriMknMenu(ActionEvent event) {

    }

    @FXML
    void makananMenu(MouseEvent event) {

    }

}
