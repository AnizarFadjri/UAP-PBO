package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class UbahPjlBrgController {

    @FXML
    private Button btnBarang;

    @FXML
    private Button btnMakanan;

    @FXML
    private Button btnUbahPjl;

    @FXML
    private TextField fieldIDPjlSebelum;

    @FXML
    private TextField fieldIDPjlSesudah;

    @FXML
    private TextField fieldJmlBrg;

    @FXML
    private TextField fieldNamaBrg;

    @FXML
    private TextField fieldPajakBrg;

    @FXML
    private TextField fieldStokBrg;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtBarang;

    @FXML
    private Text txtHome;

    @FXML
    private Text txtPenjualan;

    @FXML
    void barangMenu(MouseEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void makananMenu(ActionEvent event) {

    }

    @FXML
    void penjualanMenu(ActionEvent event) {

    }

}
