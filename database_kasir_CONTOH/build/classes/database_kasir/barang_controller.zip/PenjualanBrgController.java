package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class PenjualanBrgController {

    @FXML
    private Button btnBarang;

    @FXML
    private Button btnHapusPjl;

    @FXML
    private Button btnMakanan;

    @FXML
    private Button btnTambahPjl;

    @FXML
    private Button btnUbahPjl;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtBarang;

    @FXML
    private Text txtHome;

    @FXML
    void BarangMenu(ActionEvent event) {

    }

    @FXML
    void barangMenu(MouseEvent event) {

    }

    @FXML
    void hapusPjlMenu(ActionEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void makananMenu(ActionEvent event) {

    }

    @FXML
    void tambahPjlMenu(ActionEvent event) {

    }

    @FXML
    void ubahPjlMenu(ActionEvent event) {

    }

}
