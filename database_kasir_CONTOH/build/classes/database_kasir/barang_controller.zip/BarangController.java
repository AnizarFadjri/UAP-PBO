package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class BarangController {

    @FXML
    private Button btnHapusBrg;

    @FXML
    private Button btnKategoriBrg;

    @FXML
    private Button btnMakanan;

    @FXML
    private Button btnPenjualanBrg;

    @FXML
    private Button btnTambahBrg;

    @FXML
    private Button btnUbahBrg;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtHome;

    @FXML
    void hapusBrgMenu(ActionEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void kategoriBrgMenu(ActionEvent event) {

    }

    @FXML
    void makananMenu(ActionEvent event) {

    }

    @FXML
    void penjualanBrgMenu(ActionEvent event) {

    }

    @FXML
    void tambahBrgMenu(ActionEvent event) {

    }

    @FXML
    void ubahBrgMenu(ActionEvent event) {

    }

}
