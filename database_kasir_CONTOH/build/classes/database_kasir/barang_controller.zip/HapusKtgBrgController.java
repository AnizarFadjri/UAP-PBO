package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class HapusKtgBrgController {

    @FXML
    private Button btnBarang;

    @FXML
    private Button btnHapusKtg;

    @FXML
    private Button btnMakanan;

    @FXML
    private TextField fieldIDKtgBrg;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtBarang;

    @FXML
    private Text txtHome;

    @FXML
    private Text txtKategori;

    @FXML
    void barangMenu(MouseEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void kategoriMenu(ActionEvent event) {

    }

    @FXML
    void makananMenu(ActionEvent event) {

    }

}
