package database_kasir;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class KategoriBrgController {

    @FXML
    private Button btnBarang;

    @FXML
    private Button btnHapusKtgBrg;

    @FXML
    private Button btnMakanan;

    @FXML
    private Button btnTambahKtgBrg;

    @FXML
    private Button btnUbahKtgBrg;

    @FXML
    private Pane paneMenu;

    @FXML
    private Text txtBarang;

    @FXML
    private Text txtHome;

    @FXML
    void barangMenu(MouseEvent event) {

    }

    @FXML
    void hapusKtgBrgMenu(ActionEvent event) {

    }

    @FXML
    void homeMenu(MouseEvent event) {

    }

    @FXML
    void makananMenu(ActionEvent event) {

    }

    @FXML
    void tambahKtgBrgMenu(ActionEvent event) {

    }

    @FXML
    void ubahKtgBrgMenu(ActionEvent event) {

    }

}
